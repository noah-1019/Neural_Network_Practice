
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
import math
import pandas as pd

def mse(x, y):
    """
    Calculates the mean square error of 2, one dimensional vectors
    of the same length. All entries must be arrays or numpy arrays.
    :param x: A 1D numerical vector
    :param y: A 1D numerical vector
    :return: The mean square error of vector 1 and vector 2.
    """

    if len(x)!=len(y):
        print("Vectors have different length")
        return None 
    else:
        n=len(x)
        residual2=(x-y)**2
        MSE=sum(residual2)/n

        return(MSE)
    
def plotRegression (x, y):
    """
    Given 2 1D vectors plotRegression plots the y vs x graph,
    which includes the corelation coefficient value useful in 
    determining statistical significance.
    :param x: A 1D numerical vector representing the x axis (predictor variable)
    :param y: A 1D numerical vector representing the y axis (actual variable)
    :return: The Coefficients of the regression line.
    """

    coef=np.polyfit(x,y,1)
    poly1d_fn=np.poly1d(coef) # This function creates a function that predicts a y value given an x value.
    R=cor_coef(x,y)

    plt.plot(x,y,'yo',x,poly1d_fn(x), '--k')
    plt.xlabel("Predicted Values")
    plt.ylabel("Actual Values")
    plt.title("R:    "+str(R))

    plt.show()



def cor_coef(x,y):
    """
    Given 2 1D vectors cor_coef calculates the corelation coefficient value 
    useful in determining statistical significance.
    :param x: A 1D numerical vector representing the x axis (predictor variable)
    :param y: A 1D numerical vector representing the y axis (actual variable)
    :return: The correlation coefficient
    """

    xBar=np.mean(x)
    yBar=np.mean(y)


    xDiff=x-xBar
    yDiff=y-yBar

    num=sum(xDiff*yDiff)

    denom=(sum(xDiff**2)*sum(yDiff**2))**(1/2)

    return(num/denom)


def formatData(dataframe,percent_training,percent_validation):
    """
    This function does two things: 
    1) Splitting a dataframe into testing, training, and validation sections.
    2) Normalize the data for better neural network performance 
    :param dataframe: A numerical dataframe of inputs used for neural network training. 
    :param percent_training: The percent of data as a decimal that will be used to train the NN.
    :param percent_validation: The percent of data as a decimal that will be used to validate the NN.
    :return: 3 normalized dataframes representing the training, testing and validation data. 
    """

    length=len(dataframe)

    # normalizes the data
    df=normalize(dataframe)


    trainIndex=math.floor(length*percent_training)
    valIndex=math.floor(length*(percent_training+percent_validation))

    # seperates the data
    trainingData=df.iloc[0:trainIndex]
    validationData=df.iloc[trainIndex:valIndex]
    testData=df.iloc[valIndex:length+1]

    # Creates a data object that returns the three sections of data
    class dataSet:
        def __init__(self,train,val,test):
            self.train=train
            self.val=val
            self.test=test


    return(dataSet(trainingData,validationData,testData))


def normalize(dataframe):
    """
    This function normalizes a dataframe by dividing every element by the highest value.
    :param dataframe: A numerical dataframe
    :return: The normalized dataframe
    """

    maxValues=dataframe.max(axis=0)

    df=dataframe/maxValues

    return df

